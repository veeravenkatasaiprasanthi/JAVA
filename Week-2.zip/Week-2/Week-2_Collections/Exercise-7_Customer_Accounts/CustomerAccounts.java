import java.util.Map;
import java.util.TreeMap;

public class CustomerAccounts {
    private TreeMap<Integer, Customer> customers;

    public CustomerAccounts() {
        this.customers = new TreeMap<>();
    }

    public void addCustomer(Customer customer) {
        customers.put(customer.getId(), customer);
    }

    public void removeCustomer(int customerId) {
        customers.remove(customerId);
    }

    public void displayCustomers() {
        if (customers.isEmpty()) {
            System.out.println("No customer accounts available.");
        } else {
            for (Map.Entry<Integer, Customer> entry : customers.entrySet()) {
                System.out.println(entry.getValue());
            }
        }
    }
}
