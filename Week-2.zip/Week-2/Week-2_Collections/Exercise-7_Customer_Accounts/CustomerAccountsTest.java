public class CustomerAccountsTest {
    public static void main(String[] args) {
        CustomerAccounts accounts = new CustomerAccounts();

        accounts.addCustomer(new Customer(102, "Akash", "akashjavvadi@gmail.com"));
        accounts.addCustomer(new Customer(101, "Sanjay", "sanjayi@gmail.com"));
        accounts.addCustomer(new Customer(103, "Prashanthi", "Prashanthi12@gmail.com"));

        System.out.println("Customer Accounts:");
        accounts.displayCustomers();

        accounts.removeCustomer(102);
        System.out.println("\nCustomer Accounts after removing Akash:");
        accounts.displayCustomers();
    }
}
