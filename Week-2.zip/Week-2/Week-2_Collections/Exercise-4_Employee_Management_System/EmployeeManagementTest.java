public class EmployeeManagementTest {
    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement();

        management.addEmployee(new Employee(1, "Akash Javvadi", "123 vizag AP"));
        management.addEmployee(new Employee(2, "Sanjay", "456 Vijayawada circle"));
        management.addEmployee(new Employee(3, "Kiran", "789 Srtyg uy"));

        System.out.println("Employee List:");
        management.displayEmployees();

        System.out.println("\nUpdating address for employee ID 2:");
        if (management.updateEmployee(2, "456 Updated Address")) {
            System.out.println("Update successful.");
        } else {
            System.out.println("Update failed.");
        }

        System.out.println("\nEmployee List after update:");
        management.displayEmployees();

        System.out.println("\nRemoving employee ID 3:");
        if (management.removeEmployee(3)) {
            System.out.println("Removal successful.");
        } else {
            System.out.println("Removal failed.");
        }

        System.out.println("\nEmployee List after removal:");
        management.displayEmployees();
    }
}
