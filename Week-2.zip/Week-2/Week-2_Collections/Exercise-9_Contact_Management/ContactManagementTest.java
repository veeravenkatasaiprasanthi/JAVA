public class ContactManagementTest {
    public static void main(String[] args) {
        ContactManagement contactManagement = new ContactManagement();

        contactManagement.addContact(new Contact(1, "Akash", "1254369873"));
        contactManagement.addContact(new Contact(2, "Surya", "4398736262"));
        contactManagement.addContact(new Contact(3, "Saketh","0125432156"));

        System.out.println("Contact List:");
        contactManagement.displayContacts();

        contactManagement.removeContact(2);
        System.out.println("\nContact List after removing Surya:");
        contactManagement.displayContacts();
    }
}
