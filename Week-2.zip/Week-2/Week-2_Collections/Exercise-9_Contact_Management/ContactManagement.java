import java.util.Hashtable;
import java.util.Map;

public class ContactManagement {
    private Hashtable<Integer, Contact> contacts;

    public ContactManagement() {
        this.contacts = new Hashtable<>();
    }

    public void addContact(Contact contact) {
        contacts.put(contact.getId(), contact);
    }

    public void removeContact(int contactId) {
        contacts.remove(contactId);
    }

    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts in the system.");
        } else {
            for (Map.Entry<Integer, Contact> entry : contacts.entrySet()) {
                System.out.println(entry.getValue());
            }
        }
    }
}
