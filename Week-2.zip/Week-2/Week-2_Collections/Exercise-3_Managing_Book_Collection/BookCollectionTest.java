public class BookCollectionTest {
    public static void main(String[] args) {
        BookCollection collection = new BookCollection();

        System.out.println("Adding 'Data Structures': " + collection.addBook("Data Structures"));
        System.out.println("Adding '1984': " + collection.addBook("1984"));
        System.out.println("Adding 'Harry Potter': " + collection.addBook("Harry Potter"));
        System.out.println("Adding '1984' again: " + collection.addBook("1984")); // Should return false

        System.out.println("\nBook Collection:");
        collection.displayBooks();

        System.out.println("\nRemoving '1984': " + collection.removeBook("1984"));

        System.out.println("\nBook Collection after removal:");
        collection.displayBooks();
    }
}
