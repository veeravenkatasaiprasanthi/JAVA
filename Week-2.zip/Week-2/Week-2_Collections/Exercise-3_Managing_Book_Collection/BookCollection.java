import java.util.LinkedHashSet;

public class BookCollection {
    private LinkedHashSet<String> books;

    public BookCollection() {
        this.books = new LinkedHashSet<>();
    }

    public boolean addBook(String bookTitle) {
        if (bookTitle == null || bookTitle.trim().isEmpty()) {
            throw new IllegalArgumentException("Book title cannot be null or empty.");
        }
        return books.add(bookTitle); // returns false if the book is already in the set
    }

    public boolean removeBook(String bookTitle) {
        return books.remove(bookTitle);
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("No books in the collection.");
        } else {
            for (String book : books) {
                System.out.println(book);
            }
        }
    }
}
