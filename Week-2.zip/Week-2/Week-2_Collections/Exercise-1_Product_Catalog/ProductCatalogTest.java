public class ProductCatalogTest
{
    public static void main(String[] args) {
        ProductCatalog catalog = new ProductCatalog();

        System.out.println("Adding 'Laptop': " + catalog.addProduct("Laptop"));
        System.out.println("Adding 'Smartphone': " + catalog.addProduct("Smartphone"));
        System.out.println("Adding 'Tablet': " + catalog.addProduct("Tablet"));
        System.out.println("Adding 'Laptop' again: " + catalog.addProduct("Laptop")); // Should return false

        System.out.println("\nProduct Catalog:");
        catalog.displayProducts();

        System.out.println("\nSearching for 'Smartphone': " + catalog.searchProduct("Smartphone"));

        System.out.println("Removing 'Tablet': " + catalog.removeProduct("Tablet"));

        System.out.println("\nProduct Catalog after removal:");
        catalog.displayProducts();
    }
}
