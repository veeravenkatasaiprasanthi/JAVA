import java.util.*;
public class ProductCatalog
{
    private HashSet<String> products;
    public ProductCatalog()
    {
        this.products=new HashSet<>();
    }

    public boolean addProduct(String productName) {
        if (productName == null || productName.trim().isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be null or empty.");
        }
        return products.add(productName); // returns false if the product is already in the set
    }

    public boolean removeProduct(String productName) {
        return products.remove(productName);
    }

    public boolean searchProduct(String productName) {
        return products.contains(productName);
    }

    public void displayProducts() {
        Iterator<String> itr = products.iterator();
        while(itr.hasNext())
        {
             System.out.println(itr.next());

        }
    
    }
}
