import java.util.*;

public class InventoryManagement {
    private HashMap<Integer, Product> products;

    public InventoryManagement() {
        this.products = new HashMap<>();
    }

    public void addProduct(Product product) {
        products.put(product.getId(), product);
    }

    public void removeProduct(int productId) {
        products.remove(productId);
    }

    public void updateProductQuantity(int productId, int newQuantity) {
        Product product = products.get(productId);
        if (product != null) {
            product.setQuantity(newQuantity);
        }
    }

    public void displayProducts() {
        if (products.isEmpty()) {
            System.out.println("No products in the inventory.");
        } else {
            for (Map.Entry<Integer, Product> entry : products.entrySet()) {
                System.out.println(entry.getValue());
            }
        }
    }
}
