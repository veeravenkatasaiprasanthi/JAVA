public class InventoryManagementTest {
    public static void main(String[] args) {
        InventoryManagement inventory = new InventoryManagement();

 
        inventory.addProduct(new Product(1, "Laptop", 10));
        inventory.addProduct(new Product(2, "Smartphone", 20));
        inventory.addProduct(new Product(3, "Tablet", 15));

        System.out.println("Current Inventory:");
        inventory.displayProducts();

        inventory.updateProductQuantity(2, 25);
        System.out.println("\nInventory after updating quantity:");
        inventory.displayProducts();

        inventory.removeProduct(3);
        System.out.println("\nInventory after removing a product:");
        inventory.displayProducts();
    }
}
