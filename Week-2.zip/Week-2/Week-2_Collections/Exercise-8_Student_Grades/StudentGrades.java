import java.util.LinkedHashMap;
import java.util.Map;

public class StudentGrades {
    private LinkedHashMap<Integer, Student> students;

    public StudentGrades() {
        this.students = new LinkedHashMap<>();
    }

    public void addStudent(Student student) {
        students.put(student.getId(), student);
    }

    public void removeStudent(int studentId) {
        students.remove(studentId);
    }

    public void updateStudentGrade(int studentId, char newGrade) {
        Student student = students.get(studentId);
        if (student != null) {
            student.setGrade(newGrade);
        }
    }

    public void displayStudents() {
        if (students.isEmpty()) {
            System.out.println("No students in the system.");
        } else {
            for (Map.Entry<Integer, Student> entry : students.entrySet()) {
                System.out.println(entry.getValue());
            }
        }
    }
}
