public class StudentGradesTest {
    public static void main(String[] args) {
        StudentGrades studentGrades = new StudentGrades();

        studentGrades.addStudent(new Student(1, "Akash", 'A'));
        studentGrades.addStudent(new Student(2, "Eshwar", 'B'));
        studentGrades.addStudent(new Student(3, "Bhavana", 'C'));

        System.out.println("Student Grades:");
        studentGrades.displayStudents();

        studentGrades.updateStudentGrade(2, 'A');
        System.out.println("\nStudent Grades after updating Eshwar's grade:");
        studentGrades.displayStudents();

        studentGrades.removeStudent(3);
        System.out.println("\nStudent Grades after removing Bhavana:");
        studentGrades.displayStudents();
    }
}
