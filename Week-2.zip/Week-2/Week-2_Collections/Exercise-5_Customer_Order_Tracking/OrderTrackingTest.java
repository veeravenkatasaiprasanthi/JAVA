public class OrderTrackingTest {
    public static void main(String[] args) {
        OrderTracking tracking = new OrderTracking();

        tracking.addOrder(new Order(1, "Pizza"));
        tracking.addOrder(new Order(2, "Burger"));
        tracking.addOrder(new Order(3, "Pasta"));

        System.out.println("Current Orders:");
        tracking.displayOrders();

        System.out.println("\nProcessing Order: " + tracking.processOrder());

        System.out.println("\nCurrent Orders after processing one order:");
        tracking.displayOrders();

        System.out.println("\nProcessing all remaining orders:");
        while (tracking.processOrder() != null) {
            System.out.println(tracking.processOrder());
            tracking.displayOrders();
            System.out.println("\n");
        }

        // Displaying orders after all processed
        System.out.println("No orders left:");
        tracking.displayOrders();
    }
}
