import java.util.List;
import java.util.stream.Collectors;

public class FileProcessorApp {
    public static void main(String[] args) {
        String inputFileName = "sales_data.txt";
        String outputFileName = "processed_sales_data.txt";

        LargeFileReader fileReader = new LargeFileReader();
        List<String> salesData = fileReader.readLargeFile(inputFileName);

        List<String> processedData = salesData.stream()
            .filter(line -> !line.trim().isEmpty()) 
            .collect(Collectors.toList());

        LargeFileWriter fileWriter = new LargeFileWriter();
        fileWriter.writeProcessedData(outputFileName, processedData);

        String nonExistentFile = "non_existent_file.txt";
        System.out.println("\nAttempting to read from " + nonExistentFile + ":");
        fileReader.readLargeFile(nonExistentFile);

        String restrictedFile = "/restricted_directory/processed_data.txt";
        System.out.println("\nAttempting to write to " + restrictedFile + ":");
        fileWriter.writeProcessedData(restrictedFile, processedData);
    }
}
