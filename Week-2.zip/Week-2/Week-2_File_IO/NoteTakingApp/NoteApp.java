import java.util.Scanner;

public class NoteApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your note:");
        String note = scanner.nextLine();

        String fileName = "note.txt";

        FileWriterDemo fileWriterDemo = new FileWriterDemo();
        fileWriterDemo.saveNoteToFile(fileName, note);

        FileReaderDemo fileReaderDemo = new FileReaderDemo();
        System.out.println("Reading note from file:");
        fileReaderDemo.readNoteFromFile(fileName);
        
        scanner.close();
    }
}
