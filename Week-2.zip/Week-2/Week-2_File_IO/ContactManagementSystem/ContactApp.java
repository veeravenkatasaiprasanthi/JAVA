public class ContactApp {
    public static void main(String[] args) {
        String fileName = "contact.ser";

        Contact contact = new Contact("Akash Javvadi", "123-456-7890", "akashjavvadi@gmail.com");

        ContactWriter contactWriter = new ContactWriter();
        contactWriter.saveContact(fileName, contact);

        ContactReader contactReader = new ContactReader();
        Contact readContact = contactReader.readContact(fileName);

        if (readContact != null) {
            System.out.println("Contact read from file: " + readContact);
        }

        String nonExistentFile = "non_existent_contact.ser";
        System.out.println("\nAttempting to read from " + nonExistentFile + ":");
        Contact nonExistentContact = contactReader.readContact(nonExistentFile);

        if (nonExistentContact != null) {
            try {
                // Contact anotherContact = (Contact) nonExistentContact; // This is just for demonstration for future
            } catch (ClassCastException e) {
                System.err.println("Class cast error: " + e.getMessage());
            }
        }
    }
}
