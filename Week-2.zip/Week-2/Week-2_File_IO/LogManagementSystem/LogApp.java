public class LogApp {
    public static void main(String[] args) {
        String fileName = "log.txt";
        
        LogWriter logWriter = new LogWriter();
        LogReader logReader = new LogReader();
       
        logWriter.writeLog(fileName, "Log message 1");
        logWriter.writeLog(fileName, "Log message 2");
        logWriter.writeLog(fileName, "Log message 3");
    
        System.out.println("Reading logs from " + fileName + ":");
        logReader.readLogs(fileName);

        String nonExistentFile = "non_existent_log.txt";
        System.out.println("\nAttempting to read from " + nonExistentFile + ":");
        logReader.readLogs(nonExistentFile);
    }
}
