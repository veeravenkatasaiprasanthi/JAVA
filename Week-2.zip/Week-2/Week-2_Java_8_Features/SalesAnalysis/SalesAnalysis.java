import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SalesAnalysis {
    private List<SalesRecord> salesRecords = Arrays.asList(
        new SalesRecord(1, "Akash", "South", 1200.50, LocalDate.of(2023, 5, 10)),
        new SalesRecord(2, "Mahesh", "South", 950.00, LocalDate.of(2023, 5, 11)),
        new SalesRecord(3, "Tejaswini", "East", 1300.00, LocalDate.of(2023, 5, 12)),
        new SalesRecord(4, "Akash", "South", 1500.75, LocalDate.of(2023, 5, 13)),
        new SalesRecord(5, "Mahesh", "West", 800.00, LocalDate.of(2023, 5, 14))
    );

    public static void main(String[] args) {
        SalesAnalysis analysis = new SalesAnalysis();

        // Task 4: Filter Sales Records
        System.out.println("Sales records for the 'North' region:");
        analysis.filterSalesRecords("North");

        // Task 5: Map and Transform Data
        System.out.println("\nSales amounts for the 'North' region:");
        analysis.mapAndTransformData("North");

        // Task 6: Calculate Total Sales
        System.out.println("\nTotal sales amount for the 'North' region:");
        analysis.calculateTotalSales("North");

        // Task 7: Group Sales by SalesPerson
        System.out.println("\nGrouped sales records by salesperson:");
        analysis.groupSalesBySalesPerson();

        // Task 8: Generate Sales Report
        System.out.println("\nSales report:");
        analysis.generateSalesReport();
    }

    public void filterSalesRecords(String region) {
        salesRecords.stream()
            .filter(record -> record.getRegion().equalsIgnoreCase(region))
            .forEach(System.out::println);
    }

    public void mapAndTransformData(String region) {
        salesRecords.stream()
            .filter(record -> record.getRegion().equalsIgnoreCase(region))
            .map(SalesRecord::getAmount)
            .forEach(System.out::println);
    }

    public void calculateTotalSales(String region) {
        double totalSales = salesRecords.stream()
            .filter(record -> record.getRegion().equalsIgnoreCase(region))
            .mapToDouble(SalesRecord::getAmount)
            .sum();
        System.out.println(totalSales);
    }

    public void groupSalesBySalesPerson() {
        Map<String, List<SalesRecord>> groupedBySalesPerson = salesRecords.stream()
            .collect(Collectors.groupingBy(SalesRecord::getSalesPerson));
        groupedBySalesPerson.forEach((salesPerson, records) -> {
            System.out.println(salesPerson + ": " + records);
        });
    }

    public void generateSalesReport() {
        Map<String, Double> salesReport = salesRecords.stream()
            .collect(Collectors.groupingBy(SalesRecord::getSalesPerson, Collectors.summingDouble(SalesRecord::getAmount)));
        salesReport.forEach((salesPerson, totalSales) -> {
            System.out.println(salesPerson + ": " + totalSales);
        });
    }
}
