import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SalesAnalysis {

    private List<SalesRecord> salesRecords = Arrays.asList(
        new SalesRecord(1, "Akash", "North", 1200.50, LocalDate.of(2023, 5, 10), "Electronics", 10),
        new SalesRecord(2, "Mahesh", "South", 950.00, LocalDate.of(2023, 5, 11), "Furniture", 5),
        new SalesRecord(3, "Charlie", "East", 1300.00, LocalDate.of(2023, 5, 12), "Electronics", 8),
        new SalesRecord(4, "Akash", "North", 1500.75, LocalDate.of(2023, 5, 13), "Furniture", 15),
        new SalesRecord(5, "Mahesh", "West", 800.00, LocalDate.of(2023, 5, 14), "Electronics", 20)
    );

    public static void main(String[] args) {
        SalesAnalysis analysis = new SalesAnalysis();

        System.out.println("Filtered and sorted sales records for 'Electronics' category:");
        analysis.filterAndSortRecords("Electronics");

        System.out.println("\nAverage sales amount for 'North' region:");
        analysis.calculateAverageSales("North");

        System.out.println("\nTop sales record:");
        analysis.findTopSalesRecord();

        System.out.println("\nParallel stream operations:");
        analysis.parallelStreamOperations();
    }

    public void filterAndSortRecords(String category) {
        salesRecords.stream()
            .filter(record -> record.getProductCategory().equalsIgnoreCase(category))
            .sorted((r1, r2) -> r1.getDate().compareTo(r2.getDate()))
            .forEach(System.out::println);
    }

    public void calculateAverageSales(String region) {
        double averageSales = salesRecords.stream()
            .filter(record -> record.getRegion().equalsIgnoreCase(region))
            .mapToDouble(SalesRecord::getAmount)
            .average()
            .orElse(0.0);
        System.out.println(averageSales);
    }

    public void findTopSalesRecord() {
        SalesRecord topSalesRecord = salesRecords.stream()
            .max((r1, r2) -> Double.compare(r1.getAmount(), r2.getAmount()))
            .orElse(null);
        System.out.println(topSalesRecord);
    }

    public void parallelStreamOperations() {
        long startTime = System.nanoTime();
        salesRecords.parallelStream()
            .filter(record -> record.getProductCategory().equalsIgnoreCase("Electronics"))
            .sorted((r1, r2) -> r1.getDate().compareTo(r2.getDate()))
            .forEach(System.out::println);
        long endTime = System.nanoTime();
        System.out.println("Time taken: " + (endTime - startTime) + " ns");
    }
}
