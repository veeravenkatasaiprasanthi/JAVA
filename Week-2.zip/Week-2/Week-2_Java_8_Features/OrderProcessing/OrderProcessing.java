import java.util.ArrayList;
import java.util.List;

public class OrderProcessing {
    private List<Order> orders = new ArrayList<>();

    public void addOrder(Order order) {
        orders.add(order);
    }

    public void filterOrders(OrderFilter filter) {
        for (Order order : orders) {
            if (filter.filter(order)) {
                System.out.println(order);
            }
        }
    }

    public void processOrders(OrderProcessor processor) {
        for (Order order : orders) {
            processor.process(order);
        }
    }

    public static void main(String[] args) {
        OrderProcessing orderProcessing = new OrderProcessing();

        orderProcessing.addOrder(new Order(1, "Akash", 250.0, "NEW"));
        orderProcessing.addOrder(new Order(2, "Eshwar", 150.0, "NEW"));
        orderProcessing.addOrder(new Order(3, "Shanmukh", 350.0, "NEW"));

        OrderFilter highValueFilter = order -> order.getOrderAmount() > 200;

        OrderProcessor markAsProcessed = order -> order.setStatus("PROCESSED");

        System.out.println("Filtering orders with amount greater than 200:");
        orderProcessing.filterOrders(highValueFilter);

        System.out.println("\nProcessing orders to change their status to 'PROCESSED':");
        orderProcessing.processOrders(markAsProcessed);

        System.out.println("\nAll orders after processing:");
        for (Order order : orderProcessing.orders) {
            System.out.println(order);
        }
    }
}
