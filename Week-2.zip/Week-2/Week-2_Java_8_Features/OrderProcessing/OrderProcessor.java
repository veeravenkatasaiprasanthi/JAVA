public interface OrderProcessor {
    void process(Order order);
}
