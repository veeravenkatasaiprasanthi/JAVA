
public interface FeedbackProcessor {
    void process(Feedback feedback);
}
