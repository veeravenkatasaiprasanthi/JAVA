import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FeedbackAnalysis {

    private List<Feedback> feedbackList = Arrays.asList(
        new Feedback(1, "Akash", 5, "Great service!"),
        new Feedback(2, "Mahesh", 3, "Average experience."),
        new Feedback(3, "Charan", 4, "Good service."),
        new Feedback(4, "Dinesh", 2, "Not satisfied."),
        new Feedback(5, "Eve", 5, "Excellent!")
    );

    public static void main(String[] args) {
        FeedbackAnalysis analysis = new FeedbackAnalysis();

        System.out.println("Feedback with rating >= 4:");
        analysis.filterFeedback(feedback -> feedback.getRating() >= 4).forEach(System.out::println);

        System.out.println("\nCustomer names and comments:");
        analysis.mapFeedback().forEach(System.out::println);

        System.out.println("\nCount of positive and negative feedbacks:");
        Map<Boolean, Long> feedbackCounts = analysis.countFeedback(feedback -> feedback.getRating() >= 4);
        System.out.println("Positive feedback: " + feedbackCounts.get(true));
        System.out.println("Negative feedback: " + feedbackCounts.get(false));
    }

    public List<Feedback> filterFeedback(FeedbackFilter filter) {
        return feedbackList.stream()
            .filter(filter::filter)
            .collect(Collectors.toList());
    }

    public List<String> mapFeedback() {
        return feedbackList.stream()
            .map(feedback -> feedback.getCustomerName() + ": " + feedback.getComments())
            .collect(Collectors.toList());
    }

    public Map<Boolean, Long> countFeedback(FeedbackFilter filter) {
        return feedbackList.stream()
            .collect(Collectors.partitioningBy(filter::filter, Collectors.counting()));
    }
}
