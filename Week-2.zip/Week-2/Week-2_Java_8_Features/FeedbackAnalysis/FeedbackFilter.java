public interface FeedbackFilter {
    boolean filter(Feedback feedback);
}
