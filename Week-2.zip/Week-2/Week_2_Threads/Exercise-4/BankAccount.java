public class BankAccount {
    private double balance;

    public synchronized void deposit(double amount) {
        balance += amount;
        System.out.println(Thread.currentThread().getName() + " deposited: " + amount + ", New Balance: " + balance);
    }

    public synchronized void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println(Thread.currentThread().getName() + " withdrew: " + amount + ", New Balance: " + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " tried to withdraw: " + amount + ", Insufficient Balance: " + balance);
        }
    }

    public static void main(String[] args) {
        BankAccount account = new BankAccount();

        // Create and start multiple Transaction threads
        Thread t1 = new Thread(new Transaction(account, TransactionType.DEPOSIT, 1000), "Thread1");
        Thread t2 = new Thread(new Transaction(account, TransactionType.WITHDRAW, 500), "Thread2");
        Thread t3 = new Thread(new Transaction(account, TransactionType.WITHDRAW, 700), "Thread3");

        t1.start();
        t2.start();
        t3.start();

        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All transactions have completed.");
    }
}

class Transaction implements Runnable {
    private BankAccount account;
    private TransactionType type;
    private double amount;

    public Transaction(BankAccount account, TransactionType type, double amount) {
        this.account = account;
        this.type = type;
        this.amount = amount;
    }

    @Override
    public void run() {
        if (type == TransactionType.DEPOSIT) {
            account.deposit(amount);
        } else if (type == TransactionType.WITHDRAW) {
            account.withdraw(amount);
        }
    }
}

enum TransactionType {
    DEPOSIT, WITHDRAW
}
