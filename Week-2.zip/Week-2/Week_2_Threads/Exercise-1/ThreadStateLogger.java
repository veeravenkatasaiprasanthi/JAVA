public class ThreadStateLogger {
    public static void main(String[] args) {

        Thread thread = new Thread(new SimpleTask());

        
        System.out.println("State before starting: " + thread.getState());

        thread.start();
        System.out.println("State after starting: " + thread.getState());

        try {
            while (thread.isAlive()) {
                System.out.println("State during execution: " + thread.getState());
                Thread.sleep(500); 
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("State after completion: " + thread.getState());
    }
}

class SimpleTask implements Runnable {
    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Task execution: " + i);
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
