import java.util.LinkedList;
import java.util.Queue;

public class ProducerConsumer {
    public static void main(String[] args) {
        DataQueue dataQueue = new DataQueue();

        Thread producer1 = new Thread(new Producer(dataQueue), "Producer1");
        Thread producer2 = new Thread(new Producer(dataQueue), "Producer2");
        Thread consumer1 = new Thread(new Consumer(dataQueue), "Consumer1");
        Thread consumer2 = new Thread(new Consumer(dataQueue), "Consumer2");

        producer1.start();
        producer2.start();
        consumer1.start();
        consumer2.start();

        try {
            producer1.join();
            producer2.join();
            consumer1.join();
            consumer2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All producer and consumer threads have completed.");
    }
}

class DataQueue {
    private final int MAX_CAPACITY = 5;
    private Queue<Integer> queue = new LinkedList<>();

    public synchronized void produce(int data) throws InterruptedException {
        while (queue.size() == MAX_CAPACITY) {
            wait();
        }

        queue.add(data);
        System.out.println(Thread.currentThread().getName() + " produced: " + data);
        notifyAll();
    }

    public synchronized int consume() throws InterruptedException {
        while (queue.isEmpty()) {
            wait();
        }

        int data = queue.poll();
        System.out.println(Thread.currentThread().getName() + " consumed: " + data);
        notifyAll();
        return data;
    }
}

class Producer implements Runnable {
    private DataQueue dataQueue;

    public Producer(DataQueue dataQueue) {
        this.dataQueue = dataQueue;
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                int data = (int) (Math.random() * 100);
                dataQueue.produce(data);
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class Consumer implements Runnable {
    private DataQueue dataQueue;

    public Consumer(DataQueue dataQueue) {
        this.dataQueue = dataQueue;
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                dataQueue.consume();
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
