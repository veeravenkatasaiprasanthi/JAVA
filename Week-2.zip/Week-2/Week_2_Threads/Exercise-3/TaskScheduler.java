public class TaskScheduler {
    public static void main(String[] args) {

        Thread task1 = new Thread(new Task("Task1"));
        Thread task2 = new Thread(new Task("Task2"));
        Thread task3 = new Thread(new Task("Task3", task1));

        task1.start();
        task2.start();
        task3.start();

        try {
            task1.join();
            task2.join();
            task3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All tasks have completed.");
    }
}

class Task implements Runnable {
    private String name;
    private Thread dependentTask;

    public Task(String name) {
        this.name = name;
    }

    public Task(String name, Thread dependentTask) {
        this.name = name;
        this.dependentTask = dependentTask;
    }

    @Override
    public void run() {
        try {
            if (dependentTask != null) {
                System.out.println(name + " is waiting for " + dependentTask.getName() + " to complete.");
                dependentTask.join();
            }

            for (int i = 0; i < 5; i++) {
                System.out.println(name + " is executing step " + (i + 1));
                if (i == 2) {
                    System.out.println(name + " is yielding to other tasks.");
                    Thread.yield();
                }
                Thread.sleep(1000); 
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
