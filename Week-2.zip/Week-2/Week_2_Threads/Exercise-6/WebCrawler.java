import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WebCrawler {
    private static final int NUM_THREADS = 4;
    private static final ExecutorService executor = Executors.newFixedThreadPool(NUM_THREADS);
    private static final Map<String, String> crawledData = new ConcurrentHashMap<>();
    private static final AtomicInteger activeTasks = new AtomicInteger();

    public static void main(String[] args) {
       
        String[] urls = {
            "http://example.com/page1",
            "http://example.com/page2",
            "http://example.com/page3",
            "http://example.com/page4"
        };

        for (String url : urls) {
            activeTasks.incrementAndGet();
            executor.execute(new CrawlerTask(url));
        }

        while (activeTasks.get() > 0) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        executor.shutdown();

        System.out.println("Crawled Data:");
        for (Map.Entry<String, String> entry : crawledData.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }

        System.out.println("All crawling tasks have completed.");
    }

    static class CrawlerTask implements Runnable {
        private String url;

        public CrawlerTask(String url) {
            this.url = url;
        }

        @Override
        public void run() {
            try {
                String content = "Content of " + url;
                System.out.println(Thread.currentThread().getName() + " crawling " + url);
                Thread.sleep((int) (Math.random() * 3000));

                crawledData.put(url, content);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                activeTasks.decrementAndGet();
            }
        }
    }
}
